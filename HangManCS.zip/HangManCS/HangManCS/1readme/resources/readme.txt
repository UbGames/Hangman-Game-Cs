------------------------------------------------------------------------
 HangMan V1.0 - UbGames
------------------------------------------------------------------------
 This software is not free. The evaluation period for this
 software is 30 days, after which, you are legally bound to 
 register the software for continued use.

 The registration fee is $9.95 U.S. funds. Upon registration,
 a notice-free update will be sent to you. Thank you for your
 interest!

 Please feel free to distribute this software in it original
 form (original zip file). Please do not copy this program
 outside of its original zip file format.
------------------------------------------------------------------------

 UbGames

 Email: games@ubgames.com

------------------------------------------------------------------------
 Ordering information - please visit our website https://www.ubgames.com
------------------------------------------------------------------------
