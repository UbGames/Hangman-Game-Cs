HangMan Game in C# by UbGames (www.ubgames.com)

-------------------------------------------

Hangman Game in C#

The Hang Man game is built in C# and is a popular brain teaser game.

Hang Man is easy to play, but can you become an expert? You can select either Beginner or Advanced level of play.

There are nine word categories:

Animals, Food, Holidays, Home, Leisure, Seasons, Sports, Weather, and Misc.

The object of the game is to guess the word before you get hung.

At the beginning of play you select the letter you want to guess. If your right the letter is displayed, but if you are wrong?

See if you can guess the word before your hung!

This is a game that interests people of all ages.

The card matching game is an excellent resource to Learn How to Program C# Games!

Features:

Select from 9 categories:
  Animal, Food, Holidays, Home, Leisure, Seasons, Sports, Weather, Miscellaneous
Select Levels:
  Beginner
  Advanced
Hangman - head, body, left & right arms, left & right legs
Sound – turn sound on/off
Popup Windows: Help, About, Exit Game
Read/Write to a file

-------------------------------------------

 Questions contact us at https://www.ubgames.com

 Email: devteam@ubgames.com

-------------------------------------------

