-----------------------------------------------------------------
 HangMan V1.0 - UbGames.com
-----------------------------------------------------------------

Copy the hm.ini file from the root folder (C:\hangmanCs\) to the bin folder (C:\hangmanCs\bin\)

If you get the following message:

"A file is missing or corrupted!"

1. Copy the hm.ini file from the root folder (C:\hangmanCs\) to the bin folder (C:\hangmanCs\bin\)
2. Copy the all from the resources folder to the AppData folder (C:\hangmanCs\AppData\)

-----------------------------------------------------------------

 Questions contact us at https://www.ubgames.com

 Email: devteam@ubgames.com

------------------------------------------------------------------------
